﻿window.formNavigation = (function () {
    var linkControls = [];

    function onLoad() {
        var configuration = getConfiguration();
        createLinks(configuration);
        refreshLinks();
    }

    function getConfiguration() {
        var parameters = CrmSdk.getWebResourceQueryParameters();
        if (!parameters.data) {
            return null;
        }
        var configuration = JSON.parse(parameters.data);
        applyDefaultConfiguration(configuration);
        return configuration;
    }

    function applyDefaultConfiguration(configuration) {
        if(configuration.showAllLinks === undefined) {
            configuration.showAllLinks = true;
        }
        if (configuration.links === undefined) {
            configuration.links = [];
        }
    }
    
    function createLinks(configuration) {
        createLinkControls(configuration);
        populateListElement();
    }

    function createLinkControls(configuration) {
        if (configuration.showAllLinks) {
            var configLinksAsDictionary = {};
            for (var i = 0; i < configuration.links.length; i++) {
                var link = configuration.links[i];
                configLinksAsDictionary[link.navigationItemId] = link;
            }
            window.parent.Xrm.Page.ui.navigation.items.forEach(function (navigationItem) {
                var linkControl;
                var linkConfig = configLinksAsDictionary[navigationItem.getId()];
                if (linkConfig !== undefined) {
                    linkControl = createLinkControlFromLinkConfig(linkConfig);
                } else {
                    linkControl = createLinkControlFromNavigationItem(navigationItem);
                }
                linkControls.push(linkControl);
            });
        } else {
            for (var i = 0; i < configuration.links.length; i++) {
                var linkConfig = configuration.links[i];
                var linkControl = createLinkControlFromLinkConfig(linkConfig);
                linkControls.push(linkControl);
            }
        }
    }

    function createLinkControlFromNavigationItem(navigationItem) {
        return {
            navigationItemId: navigationItem.getId(),
            label: navigationItem.getLabel(),
            linkIndex: linkControls.length
        };
    }

    function createLinkControlFromLinkConfig(linkConfig) {
        var linkControl = {
            navigationItemId: linkConfig.navigationItemId,
            linkIndex: linkControls.length
        };
        if (linkConfig.relationshipName) {
            linkControl.relationshipName = linkConfig.relationshipName;
        }
        if (linkConfig.label) {
            linkControl.label = linkConfig.label;
        } else {
            linkControl.label = window.parent.Xrm.Page.ui.navigation.items.get(linkControl.navigationItemId).getLabel();
        }
        return linkControl;
    }

    function populateListElement() {
        var listElement = document.getElementById("navigationList");
        for (var i = 0; i < linkControls.length; i++) {
            var linkControl = linkControls[i];
            var listItemElement = createListItemElement(linkControl);
            listElement.appendChild(listItemElement);
        }
    }

    function createListItemElement(linkControl) {
        var listItemElement = document.createElement("LI");
        listItemElement.id = linkControl.navigationItemId;

        var linkElement = document.createElement("A");
        linkElement.href = "javascript:formNavigation.navigateTo(" + linkControl.linkIndex + ");";

        var labelElement = document.createElement("SPAN");
        labelElement.className = "label";
        labelElement.innerText = linkControl.label;
        linkElement.appendChild(labelElement);


        var countElement = document.createElement("SPAN");
        countElement.className = "count";
        countElement.id = [linkControl.navigationItemId, ".count"].join("");
        linkElement.appendChild(countElement);

        listItemElement.appendChild(linkElement);
        return listItemElement;
    }

    function navigateTo(linkIndex) {
        var linkControl = linkControls[linkIndex];
        window.parent.Xrm.Page.ui.navigation.items.get(linkControl.navigationItemId).setFocus();
    }

    function refreshLinks() {
        var entityName = window.parent.Xrm.Page.data.entity.getEntityName();
        CrmSdk.getEntitySetName(entityName, function (entitySetName) {
            var pendingRefreshes = 0;
            for (var i = 0; i < linkControls.length; i++) {
                var linkControl = linkControls[i];
                if (linkControl.relationshipName) {
                    pendingRefreshes++;
                    refreshLink(entitySetName, linkControl, function () {
                        pendingRefreshes--;
                        if (pendingRefreshes == 0) {
                            window.setTimeout(refreshLinks, 1000);
                        }
                    });
                }
            }
        }, handleError);
    }

    function refreshLink(entitySetName, linkControl, onSuccess) {
        var queryString = [
            "/", entitySetName,
            "(", window.parent.Xrm.Page.data.entity.getId().substr(1,36), ")/",
            linkControl.relationshipName, "/$count"
        ].join("");
        CrmSdk.request(
            "GET",
            queryString,
            null,
            function success(result) {
                var countElement = document.getElementById([linkControl.navigationItemId, ".count"].join(""));
                var countString = [" (", result.response, ")"].join("");
                countElement.innerText = countString;
                var fullLabel = [linkControl.label, countString].join("");
                window.parent.Xrm.Page.ui.navigation.items.get(linkControl.navigationItemId).setLabel(fullLabel);
                onSuccess();
            },
            handleError);
    }

    function handleError(message) {
        console.error(message);
    }

    return {
        onLoad: onLoad,
        refreshLinks: refreshLinks,
        navigateTo: navigateTo
    };
}());