﻿window.CrmSdk = window.CrmSdk || {};

/**
 * @function getWebResourceQueryParameters
 * @description Retrieves the query parameter passed to the current web resource.
 * @returns {string}
 */
CrmSdk.getWebResourceQueryParameters = function () {
    if (location.search == "") {
        return null;
    }
    var returnObject = {};
    var parameters = location.search.substr(1).split("&");
    for(var i = 0; i < parameters.length; i++) {
        var parameter = parameters[i].replace(/\+/g, " ");
        var parts = parameter.split("=");
        var key = parts[0];
        var value = decodeURIComponent(parts[1]);
        returnObject[key] = value;
    }
    return returnObject;
};